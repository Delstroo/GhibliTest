//
//  Films.swift
//  StudioGhibliApiTest
//
//  Created by Delstun McCray on 9/15/21.
//

import Foundation

struct Film: Codable {
    let id, title, originalTitle, originalTitleRomanised: String
    let filmDescription, director, producer, releaseDate: String
    let runningTime, rtScore: String
    let people, species, locations, vehicles: [URL]
    let url: URL

    enum CodingKeys: String, CodingKey {
        case id, title
        case originalTitle = "original_title"
        case originalTitleRomanised = "original_title_romanised"
        case filmDescription = "description"
        case director, producer
        case releaseDate = "release_date"
        case runningTime = "running_time"
        case rtScore = "rt_score"
        case people, species, locations, vehicles, url
    }
}// End of struct

